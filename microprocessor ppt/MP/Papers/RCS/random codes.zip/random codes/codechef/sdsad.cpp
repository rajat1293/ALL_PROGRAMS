#include<iostream>
using namespace std;

int main()
{
	char a[100];
	cin.get(a,100);
	cout<<cin.gcount()<<endl;
	
	cout<<cin;
	
}
