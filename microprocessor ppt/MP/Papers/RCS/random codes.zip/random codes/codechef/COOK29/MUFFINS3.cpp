#include<stdio.h>

int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
              int n;
              scanf("%d",&n);
              printf("%d\n",n/2+1);
    }
    return 0;
}
