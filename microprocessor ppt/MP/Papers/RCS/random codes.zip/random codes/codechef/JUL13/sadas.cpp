#include<iostream>
#include<cstdlib>
#include<conio.h>
using namespace std;

int main()
{
	while(!kbhit())
	{
	}
}
