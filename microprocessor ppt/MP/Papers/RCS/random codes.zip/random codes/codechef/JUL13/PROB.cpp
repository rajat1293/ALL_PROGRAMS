#include<iostream>
using namespace std;

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		long long a,b,c,t;
		cin>>a>>b>>c>>t;
		cout<<double(a)/(a+b)<<endl;
	}
}
