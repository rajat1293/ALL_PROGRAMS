#include<iostream>
#include<limits>
using namespace std;


pair<int,int> maxsubarray(int a[],int n)
{
	long long max_so_far=numeric_limits<long long>::min();
	, max_ending_here=0;

}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int a[10000];
		int n;
		cin>>n;
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
		
		pair<int,int> maxsubarr=
		
		
		
		
	}




}
