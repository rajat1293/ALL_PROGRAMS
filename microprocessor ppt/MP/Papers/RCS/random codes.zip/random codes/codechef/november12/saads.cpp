#include<stdio.h>
int main()
{
    int a;
}
