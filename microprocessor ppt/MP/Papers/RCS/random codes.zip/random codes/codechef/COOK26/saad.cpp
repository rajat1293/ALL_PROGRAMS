#include<stdio.h>
int main()
{
    printf("%d %d",sizeof(long long),sizeof(int));
    getchar();
}
