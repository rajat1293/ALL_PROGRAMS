
#include<stdio.h>
using namespace std;
int main()
{
    printf("%llf",75.47784648840000);
    getchar();
}
