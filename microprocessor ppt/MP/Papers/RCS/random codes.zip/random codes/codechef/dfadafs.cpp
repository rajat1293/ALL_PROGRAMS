#include<stdio.h>

int main()
{
	
	char p[]="Shobhit";
	fact(5);
	changestr(p);
}



int fact(int)
{
	cout<<"hi...";


}


char *changestr(char *p)
{
	printf(p);
}
