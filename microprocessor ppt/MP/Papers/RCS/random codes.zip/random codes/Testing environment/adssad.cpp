#include<iostream>
using namespace std;

int main()
{
	cout<<'\0'<<'a';
}
