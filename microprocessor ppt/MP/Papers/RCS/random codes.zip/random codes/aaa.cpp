#Include<stdio.h>
int main()
{}
