#include<iostream>
using namespace std;


int main()
{
	int i=23;
	while(1)
	{
		if(i%5==3&&i%7==4)
			break;
		i+=35;
	}
	cout<<i;

}
