#include<iostream>
using namespace std;
int f(int N,int M,int K)
{
	int tmp=0;
	cout<<N<<","<<M<<","<<K<<"\n";
	if(N==0||M==0)
	{
		if(K==0)return 1;
		return 0;
	}
	if(N==1)
	{
		if(M==1)
		{
			if(K==1)return 2;
			else return 0;
		}
		if(M>1)
		{
			if(K==1) return 2;
			else if(K==2) return M-1;
			else return 0; 
		}
	}
	else if(M==1)
	{
		if(N==1)
		{
			if(K==1)return 2;
			else return 0;
		}
		if(N>1)
		{
			if(K==1) return 2;
			else if(K==2) return N-1;
			else return 0; 
		}
	}
	if(K>=0)tmp+=(f(N-2,M,K)+f(N,M-2,K));
	if(K>0)tmp+=(f(N-2,M,K-1)+f(N,M-2,K-1));
	if(K>0)tmp+=f(N-1,M,K-1)+f(N,M-1,K-1);
	if(K>1)tmp+=f(N,M-1,K-2)+f(N-1,M,K-2);
	cout<<"->"<<tmp<<"\n";
	return tmp;
}
int main()
{
	int N,K;
	cin>>N>>K;
	cout<<f(N,N,K);
}
