#include<stdio.h>
#define macro(s) printf("%s is %d",#s,s)

int main()
{
    int s=6;
    macro(s);
    getchar();
}
