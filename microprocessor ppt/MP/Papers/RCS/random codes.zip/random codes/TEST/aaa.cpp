#include<sys/types.h>
#include<sys/socket.h>

int sockets(int domain,int type,int protocol);

