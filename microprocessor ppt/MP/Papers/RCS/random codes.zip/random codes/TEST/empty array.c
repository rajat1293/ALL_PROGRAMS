#include<stdio.h>

int a[];

int main()
{
    a[0]=1;
    printf("%d",sizeof(a));
    return 0;
}
