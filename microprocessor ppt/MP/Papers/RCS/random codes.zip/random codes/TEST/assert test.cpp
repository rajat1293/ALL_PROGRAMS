#include<assert.h>
#include<stdio.h>
int main()
{
    int i=0;
    assert(i>0);
    getchar();
}
