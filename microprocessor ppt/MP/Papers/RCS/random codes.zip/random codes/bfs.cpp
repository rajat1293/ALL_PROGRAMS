#include<stdio.h>
#include<string.h>
#define MAX 100

#define ERRNO -1


typedef struct node
{
       int data;
       struct node *next;
}node;

node * createnode(int n)
{
     node *temp=new node;
     if(temp==NULL) return NULL;
     temp->data=n;
     temp->next=NULL;
     return temp;
}

int pushnode(node **head,node **rear,node *n)
{
    if(n==NULL) return 0;
    if(*head==NULL) 
                    *rear=*head=n;
    else
    {
                    (*rear)->next=n;
                    *rear=n;
    }
    return 1;
}

int popnode(node **head,node **rear)
{
    if(*head==NULL) return ERRNO;
    else
    {
        node *temp=*head;
        int n=temp->data;
        *head=(*head)->next;
        if(head==NULL) rear=NULL;
        delete temp;
        return n;
        
    } 
        
}
#define pop() popnode(&head,&rear)
#define push(n) pushnode(&head,&rear,createnode(n))
//------------------------------------------------------------------------------

void bfs(int s,int graph[MAX][MAX],int n)
{
    int isvisited[MAX];
    memset(isvisited,0,sizeof(isvisited));
    
    node *head, *rear;
    head=rear=NULL;
    push(s);
    isvisited[s]=1;
    while(head)
    {
                     int x=pop();        
                     printf("%d",x);
              
                     for(int i=0;i<n;i++)
                     {
                            if(graph[x][i]==1&&isvisited[i]==0)
                            {
                                   isvisited[i]=1;
                                   push(i);                        
                            } 
                     }
    }
     
}
int main()
{
    
    int graph[MAX][MAX];
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
            for(int j=0;j<n;j++)
            {
                    scanf("%d",&graph[i][j]);
            }
    }
    int s;
    scanf("%d",&s);
    
    bfs(s,graph,n);
    fflush(stdin);
    getchar();
    return 0;
}
