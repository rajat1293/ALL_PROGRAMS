#include<stdio.h>
#include<conio.h>
int main()
{
    int a=1;
    printf("%d %d %d",a,a++,++a);
    getch();
}
