#include<iostream>
using namespace std;


class T
{
	public:
		
};

int main()
{
	T ob;
	T ob2=ob;
}
