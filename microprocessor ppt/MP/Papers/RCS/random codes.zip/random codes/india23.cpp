#include "stdio.h"
#include<conio.h>
main()
{
int a,b,c;
int count = 1;

for (b = c = 10;
a = "ello Folks,\
TFy!QJu ROo TNn(ROo)SLq SLq ULo+\
UHs UJq TNn*RPn/QPbEWS_JSWQAIJO^\
NBELPeHBFHT}TnALVlBLOFAkHFOuFETp\
HCStHAUFAgcEAelclcn^r^r\\tZvYxXy\
T|S~Pn SPm SOn TNn ULo0ULo#ULo-W\
Hq!WFs XDt!"[b+++0]; )
for(; a-- > 64 ; )
putchar ( ++c=='Z' ?
c = c / 9 :
33 ^ b & 1 );
getch();
return 0;
}
