#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
main()
{
int a,b,c;
int count = 1;
for (b=c=10;a="TFy!QJu ROo TNn(ROo)SLq SLq ULo+UHs UJq TNn*RPn/QPbEWS_JSWQAIJO^NBELPeHBFHT}TnALVlBLOFAkHFOuFETpHCStHAUFAgcEAelclcn^r^r\\tZvYxXyT|S~Pn SPm SOn TNn ULo0ULo#ULo-WHq!WFs XDt!"[b+++21];)
{

for(;a-->64;)
putchar ( ++c=='Z' ? c = c/ 9:33^b&1);
//getch();
}
system("pause");
return 0;
}
